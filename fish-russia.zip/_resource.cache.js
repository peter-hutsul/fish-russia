

setInterval(function() {
	console.log('dasdas');
}, 1000);